// Roda dentro da página da Netflix. Usa a API do próprio player (mexer no <video> direto para pular
// dá erro M7375), lê o que está passando e manda o estado uma vez por segundo.
(() => {
  if (window.__cineNfx) return
  window.__cineNfx = true
  let avisou = false, ultimoCmd = null
  const player = () => {
    try {
      const vp = window.netflix.appContext.state.playerApp.getAPI().videoPlayer
      const ids = vp.getAllPlayerSessionIds()
      const id = ids.find(s => s.startsWith('watch')) || ids[0]
      const p = id ? vp.getVideoPlayerBySessionId(id) : null
      if (p && !avisou) { avisou = true; console.info('[Cineminha] player da Netflix encontrado') }
      return p
    } catch { return null }
  }
  // sem a API (Netflix mudou algo): o <video> ainda pausa e continua; pular só pela API
  const video = () => document.querySelector('video')
  // título, temporada e episódio: metadados do player; se não der, o título na barra do player
  let ultimoDom = null
  function oQuePassa(p) {
    if (p) try {
      const id = p.getMovieId()
      const md = window.netflix.appContext.state.playerApp.getState().videoPlayer.videoMetadata[id]._metadata.video
      if (md.type === 'show') {
        // o id pode vir como número ou texto, e às vezes só o currentEpisode aponta o episódio
        const alvo = new Set([id, md.currentEpisode].filter(x => x != null).map(String))
        for (const s of md.seasons || []) for (const ep of s.episodes || []) {
          if (alvo.has(String(ep.id)) || alvo.has(String(ep.episodeId))) return { titulo: md.title, s: s.seq, e: ep.seq, epNome: ep.title || '', id }
        }
        const dom = doDom()
        if (dom?.e) return { ...dom, titulo: md.title }
      }
      return { titulo: md.title, s: 0, e: 0, epNome: '', id }
    } catch {}
    return doDom()
  }
  // barra do player: "T5:E10", "T5 E10", "Temporada 5 Episódio 10", "Episódio 10"…
  const RE_T = /\b(?:T|S|Temp(?:orada)?\.?|Season)\s*(\d{1,2})\b/i, RE_E = /\b(?:E|Ep\.?|Epis[óo]dio|Episode)\s*(\d{1,3})\b/i
  function doDom() {
    const el = document.querySelector('[data-uia="video-title"]')
    if (el) {
      const h = el.querySelector('h4')?.textContent?.trim()
      const spans = [...el.querySelectorAll('span')].map(s => s.textContent.trim())
      const junto = spans.join(' '), mt = junto.match(RE_T), me = junto.match(/[TS]\s*\d+\s*[:.]?\s*E\s*(\d+)/i) || junto.match(RE_E)
      const soNumero = x => /^(?:[TS]\s*\d+\s*[:.]?\s*)?(?:E|Ep\.?|Epis[óo]dio|Episode)?\s*\d+$/i.test(x) || /^(?:T|Temp(?:orada)?\.?|Season)\s*\d+[,:]?\s*(?:E|Ep\.?|Epis[óo]dio|Episode)\s*\d+$/i.test(x)
      ultimoDom = { titulo: h || el.textContent.trim(), s: mt ? +mt[1] : 0, e: me ? +me[1] : 0, epNome: spans.filter(x => x && x !== h && !soNumero(x)).pop() || '' }
    }
    return ultimoDom
  }
  // Botões que a Netflix mostra por cima do vídeo: pular abertura/resumo e, no fim, próximo episódio
  const BOTOES = {
    abertura: ['[data-uia="player-skip-intro"]', /^(pular abertura|skip intro|saltar introdu)/i],
    resumo: ['[data-uia="player-skip-recap"]', /^(pular resumo|skip recap|saltar resumo)/i],
    proximo: ['[data-uia^="next-episode-seamless-button"]', /^(pr[óo]ximo epis[óo]dio|next episode)/i],
    creditos: ['[data-uia="watch-credits-seamless-button"]', /^(assistir aos cr[ée]ditos|watch credits|ver cr[ée]ditos)/i],
  }
  const acha = qual => {
    const [sel, re] = BOTOES[qual]
    const b = document.querySelector(sel)
    if (b) return b
    return [...document.querySelectorAll('button')].find(x => x.offsetParent && re.test(x.textContent.trim()))
  }
  const botoes = () => ({ pular: acha('resumo') ? 'resumo' : acha('abertura') ? 'abertura' : '', fim: !!acha('proximo') })
  setInterval(() => {
    if (!/\/watch\//.test(location.pathname)) return
    const p = player(), v = video()
    try {
      if (p) window.postMessage({ cineNfx: 'estado', paused: p.isPaused(), t: p.getCurrentTime() / 1000, d: p.getDuration() / 1000, midia: oQuePassa(p), ...botoes() }, location.origin)
      else if (v) window.postMessage({ cineNfx: 'estado', paused: v.paused, t: v.currentTime, d: v.duration || 0, midia: oQuePassa(null), ...botoes() }, location.origin)
    } catch (e) { console.warn('[Cineminha]', e) }
  }, 1000)
  addEventListener('message', e => {
    if (e.source !== window || e.data?.cineNfx !== 'cmd') return
    const { op, d, id } = e.data
    if (id && id === ultimoCmd) return // mesmo comando chegando duas vezes: um toggle duplo não faria nada
    ultimoCmd = id
    const p = player(), v = video()
    console.info('[Cineminha] comando', op, d ?? '')
    try {
      if (op === 'pular') { (acha('resumo') || acha('abertura'))?.click(); return }
      if (op === 'proximo') { acha('proximo')?.click(); return }
      if (op === 'creditos') { acha('creditos')?.click(); (p || v)?.pause?.(); return }
      if (!p) { if (v && op === 'toggle') v.paused ? v.play() : v.pause(); else if (v && op === 'play') v.play(); else if (v && op === 'pause') v.pause(); return }
      if (op === 'toggle') p.isPaused() ? p.play() : p.pause()
      else if (op === 'play') p.play()
      else if (op === 'pause') p.pause()
      else if (op === 'at' && Number.isFinite(+d)) p.seek(Math.max(0, +d) * 1000)
      else if (op === 'seek' && Number.isFinite(+d)) p.seek(Math.max(0, p.getCurrentTime() + Math.max(-120, Math.min(120, +d)) * 1000))
    } catch (e) { console.warn('[Cineminha]', e) }
  })
})()
